
let n = 0;

// Les paramètres :
// - c : le numéro du pion choisi
// - image : le pion (l'image) cliqué
// Cette fonction utilise la variable globale
// n pour pouvoir accéder aux éléments d'id
// 'pion0', 'pion1', 'pion2' et 'pion3'

function clic(c,image) {

}