<?php session_start();
session_destroy();
?>

<!DOCTYPE html>  <! Création de la page d'accueil du site de Mastermind>
<html>
<head>
    <link rel="icon" href="images/2.png"> <!défini un icone pour l'onglet sur le navigateur ici la bille bleu>
    <title>Mastermind</title>
    <meta charset="utf-8" />
    <link type="text/css" rel="stylesheet" href="mastermind_home.css" /> <! défini le fichier css utilisé sur cette page>
    <script type="text/javascript" src="mastermind.js"></script> <!defini le fichier javascript utilisé sur cette page >
</head>
<body>
    <h1>
        <img class="logo2" src="images/Mastermind_main.png" /> <!place le logo Mastermind en haut de la page>
    </h1>
    <form method="post" action="mastermind.php" name="nbtry_form" id="nbtry_form"> <!tout ce paragraphe form à pour but de demander à l'utilisateur le nombre de coup max qu'il veut pouvoir faire ce nombre sera compris entre 1 et 100 si l'utilisateur n'entre aucun nombre, un nombre négatif ou un nombre supérieur a 100 un message d'erreur s'affiche et l'utilisateur ne peut pas continuer >
        <class id="nbtry">Number of try ? <input type="number" id="nbtry" name="nbtry" aria-describedby="nbtry-format" required placeholder="10" min="1" max="100"></class>
        <br><br>
        <input type="image" src="images/play_button.png" onmouseover="this.src='images/play_button_mouseover.png'" onmouseout="this.src='images/play_button.png'" alt="Submit"/>
    </form> <! L'input ci-dessus est un bouton de validation qui est de type image cette image change quand l'utilisateur passe la souris au dessus du boutton afin de signaler que c'est bien un bouton et pas juste une image>
    <p>
       Vincent Coppé <img class="logo" src="images/THEGANG.png" /> Jauffret Lucas <! nos noms, prénoms et notre logo en bas de page>
    </p>
</body>
