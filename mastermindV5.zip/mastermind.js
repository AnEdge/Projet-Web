
let n = 0;
let numcoup=0;

// Les paramètres :
// - c : le numéro du pion choisi
// - image : le pion (l'image) cliqué
// Cette fonction utilise la variable globale
// n pour pouvoir accéder aux éléments d'id
// 'pion0', 'pion1', 'pion2' et 'pion3'

function clic(c,image) {

if(n<4){
  let nbes=parseInt(n/4);
  let bille=numcoup%4;


document.getElementById("pion"+n).value=c;
document.getElementById(nbes+"."+bille).src=image.src;
numcoup++;
n++;



}


}
