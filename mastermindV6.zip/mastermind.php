<?php
session_start();



if(empty($_SESSION)){
$tst=nouvelleCombinaison();

$_SESSION=["nbtry" => $_POST['nbtry'],"combinaison" => $tst,"essai" => "0"];
} else {
  $_SESSION['coup'.$_SESSION["essai"]]=[$_POST['pion0'],$_POST['pion1'],$_POST['pion2'],$_POST['pion3']];
  $_SESSION['placement'.$_SESSION["essai"]]= testPlace($_SESSION['coup'.$_SESSION["essai"]],$_SESSION["combinaison"]);
  echo $_SESSION['placement'.$_SESSION["essai"]][0];
  echo $_SESSION['placement'.$_SESSION["essai"]][1];
  echo $_SESSION['combinaison'][0];
  echo $_SESSION['combinaison'][1];
  echo $_SESSION['combinaison'][2];
  echo $_SESSION['combinaison'][3];

}

function formualaire($essai) {
  echo "<form action='mastermind.php' method='post'>\n";
  echo "<input id='pion0' type='hidden' name='pion0' value='' />\n";
  echo "<input id='pion1' type='hidden' name='pion1' value='' />\n";
  echo "<input id='pion2' type='hidden' name='pion2' value='' />\n";
  echo "<input id='pion3' type='hidden' name='pion3' value='' />\n";
  $r=$essai+1;
  $_SESSION["essai"]=$_SESSION["essai"]+1;
  echo "<input id='essai' type='hidden' name='essai' value=".$r." />\n";
}

function generateur ($n,$essai) {

  for($i=0;$i<=$n;$i++) {                    //on crée n ligne qui représente le nombre de tentative
    echo "<tr>\n";
    if ($i==0) {
      echo "<td></td>";
    } else {
      echo "<td>".$i."</td>";
    } if(!empty($_SESSION["coup".$i])){

      for($j=0;$j<4;$j++){                     // on crée des cases pour l'affichage de la combonaison
        echo "<td>\n";
        echo ("<img id='$i.$j' src='images/".$_SESSION['coup'.$i][$j].".png' />\n");
        echo "</td>\n";


      }

      echo "<td class='bienplace'>\n";        // on crée une casse pour afficher le nombre de bille bien placées
      echo "<img src='images/BP_".$_SESSION['placement'.$i][0].".png'/>\n";
      echo "</td>\n";
      echo "<td class='malplace'>\n";        //on crée une casse pour afficher le nombre de bille mal placées
      echo "<img src='images/BC_".$_SESSION['placement'.$i][1].".png'/>\n";
      echo "</td>\n" ;
      echo "</tr>\n";



    } else {

      for($j=0;$j<4;$j++){                     // on crée des cases pour l'affichage de la combonaison
      echo "<td>\n";
      echo "<img id='$i.$j' src='images/vide.png' />\n";
      echo "</td>\n";
      }
      echo "<td class='bienplace'>\n";        // on crée une casse pour afficher le nombre de bille bien placées
      echo "<img src='' />\n";
      echo "</td>\n";
      echo "<td class='malplace'>\n";        //on crée une casse pour afficher le nombre de bille mal placées
      echo "<img src='' />\n";
      echo "</td>\n" ;
      echo "</tr>\n";
    }
  }


}

function nouvelleCombinaison(){
  $code=array();

  for($i=0;$i<4;$i++) {
    $code[]=rand(0,3);
    //echo $code[$i];
  }

  return $code;
}

function testPlace($coup,$comb){
  $malplace=0;
  $bien=0;
  $test=array();

  for ($i=0; $i < sizeof($coup); $i++) {
    $tmp=$coup;
    unset($tmp[$i]);

    if($coup[$i] == $comb[$i]){
      $bien++;
      $bienP[]=$coup[$i];
      $test[]=$coup[$i];


    } elseif(in_array($coup[$i], $comb) && (!in_array($coup[$i], $test))){
      $malplace ++;
      $malP[]=$coup[$i];
      $test[]=$coup[$i];
if(in_array($coup[$i],$coup)) $malplace--;
    }


  else $test[]=$coup[$i];
  }



  $valfin=array($bien,$malplace);
  return $valfin;
}

function compteurOccurence($ori,$atest){
	$chaine=implode ( "," , $ori);
	return mb_substr_count($chaine, $atest);

}



?>


<!DOCTYPE html>
<html>

<head>
  <title>Mastermind</title>
  <link rel="icon" href="images/0.png">
  <meta charset="utf-8" />
  <link type="text/css" rel="stylesheet" href="mastermind.css" />
  <script type="text/javascript" src="mastermind.js"></script>
</head>

<body>

  <h1><img src="images/Mastermind_main.png" onmouseover="this.src='images/Mastermind_main_onmousover.png'" onmouseout="this.src='images/Mastermind_main.png'"  onclick="backtohome()">

<script>
function backtohome() {
    if (confirm("Voulez vous quitter votre partie ?")) {
        window.location="mastermind_home.php";
        }
}
</script></h1>

<?php
  if ( isset($_["pion0"]) ) {
    echo "Le joueur a joué (dans l'ordre) : {$_POST['pion0']}, {$_POST['pion1']}, {$_POST['pion2']}, {$_GET['pion3']}";
  }
?>

  <table>
    <!--
      La première ligne de la table est fixe : elle contient les
      images cliquables permettant au joueur de sélectionner ses pions
    -->
    <tr>
      <td>
      </td>
      <td>
        <img src="images/0.png" onclick="clic(0,this)" />
      </td>
      <td>
        <img src="images/1.png" onclick="clic(1,this)" />
      </td>
      <td>
        <img src="images/2.png" onclick="clic(2,this)" />
      </td>
      <td>
        <img src="images/3.png" onclick="clic(3,this)" />
      </td>
      <td class="bienplace">
      </td>
      <td class="malplace">
      </td>
    </tr>



<?php generateur($_SESSION['nbtry'],$_SESSION["essai"]); // génération de l'interface de jeu avec la fonction

?>

    <!--
      Cet élément est la ligne courante dans laquelle on fait appariatre les pions choisis par le joueur.
      Elle change a chaque coup (et passe à la ligne suivante)
    -->

  </table>

  <!--
    L'attribut 'value' des éléments INPUT est rempli par JavaScript.
    L'action du formulaire est le même script (mastermind.php).
  -->
<?php
formualaire($_SESSION['essai']);
?>
    <input type="image" src="images/play_button.png" onmouseover="this.src='images/play_button_mouseover.png'" onmouseout="this.src='images/play_button.png'" alt="submit" />
  </form>
  <p>
       Vincent Coppé <img class="logo" src="images/THEGANG.png" /> Jauffret Lucas <! nos noms, prénoms et notre logo en bas de page>
  </p>
</body>

</html>
