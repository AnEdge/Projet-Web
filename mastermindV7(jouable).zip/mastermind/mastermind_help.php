<!DOCTYPE html>  
<html>
<head>
    <link rel="icon" href="images/1.png"> <! defini un icone pour l'onglet ici la bille verte>
    <title>Mastermind</title>
    <meta charset="utf-8" />
    <link type="text/css" rel="stylesheet" href="mastermind_home.css" /> <!defini le fichier css utilisé sur cette page>
    <script type="text/javascript" src="mastermind.js"></script> <!defini le fichier javascript utilisé sur cette page>
</head>
<body>
    <h1>
        <a href='mastermind_home.php'><img class="logo2" src='images/Mastermind_main.png' onmouseover="this.src='images/Mastermind_main_onmousover.png'" onmouseout="this.src='images/Mastermind_main.png'"></a> <!place le logo master mind en haut de la page et lorque que l'on clique dessus on revient a l'accueil>
    </h1>
    <h3>
        Le Mastermind est un jeu de société pour 2 joueurs dont le but est de trouver une combinaison de 4 billes de couleur placé dans 4 emplacement.
        <br>
        Principe :
        <br>
        Le joueur 1 (ici l'ordinateur) décide d'une combinaison et la garde cachée tandis que le joueur 2 (l'utilisateur) va proposer differentes combinaison afin de retrouver celle qui est cachée 
        . Ainsi lorsque le joueur 2 propose un combinaison le joueur 1 lui dit quelles billes sont bien placés et quelles billes sont de la bonne couleur mais mal placés.
        Ainsi un 2 vert et un 1 rouge signifie qu'il a 2 billes de la bonne couleur bien placés et 1 billes et de la bonne couleur mal placés.
    </h3>    
    <p>
            Vincent Coppé <img class="logo" src="images/THEGANG.png" /> Jauffret Lucas <! nos noms, prénoms et notre logo en bas de page>
    </p>
</body