<?php
session_start();

if(empty($_SESSION)){
$tst=nouvelleCombinaison();

$_SESSION=["nbtry" => $_POST['nbtry'],"combinaison" => $tst,"essai" => "0"];
} else {
  $_SESSION['coup'.$_SESSION["essai"]]=[$_POST['pion0'],$_POST['pion1'],$_POST['pion2'],$_POST['pion3']];
  $_SESSION['placement'.$_SESSION["essai"]]= testPlace($_SESSION['coup'.$_SESSION["essai"]],$_SESSION["combinaison"]);
}

function formualaire($essai) {
  if (isset($_SESSION['coup'.$_SESSION["essai"]])) {
   
    if ($_SESSION['combinaison']==$_SESSION['coup'.$_SESSION["essai"]]){ //buger la prémiere fois qu'on lance le code
      echo "<br>Vous avez Gagnez ! En seulement ".$_SESSION["essai"]." coup.\n<br>";
      echo "<br>\n<img onclick=\"lose()\" src=\"images/replay_button.png\" onmouseover=\"this.src='images/replay_button_mouseover.png'\" onmouseout=\"this.src='images/replay_button.png'\"/>\n";
   
    } elseif ($_SESSION["essai"]==$_SESSION['nbtry']){ // lorque que l'on arrive au nombre max d'essai si l'on a pas gagnez le message ci dessous est affiché et la solution est donnée
    echo "<br>Vous avez perdu !\n<br>La bonne réponse étais :\n<br>\n";
    for($i=0;$i<=3;$i++){
      if ($_SESSION['combinaison'][$i]==0){
        echo "<img src=\"images/0.png\" >\n";
      } elseif ($_SESSION['combinaison'][$i]==1) {
        echo "<img src=\"images/1.png\" >\n";
      } elseif ($_SESSION['combinaison'][$i]==2) {
        echo "<img src=\"images/2.png\" >\n";
      } elseif ($_SESSION['combinaison'][$i]==3) {
        echo "<img src=\"images/3.png\" >\n";
      }
    } 
    echo "<br>\n<img onclick=\"lose()\" src=\"images/replay_button.png\" onmouseover=\"this.src='images/replay_button_mouseover.png'\" onmouseout=\"this.src='images/replay_button.png'\"/>\n";
    
    } else {
      echo "<form action='mastermind.php' method='post'>\n";
      echo "<input id='pion0' type='hidden' name='pion0' value='vide' />\n";
      echo "<input id='pion1' type='hidden' name='pion1' value='vide' />\n";
      echo "<input id='pion2' type='hidden' name='pion2' value='vide' />\n";
      echo "<input id='pion3' type='hidden' name='pion3' value='vide' />\n";
      $r=$essai+1;
      $_SESSION["essai"]=$_SESSION["essai"]+1;
      echo "<input id='essai' type='hidden' name='essai' value=".$r." />\n";
      echo "<input type=\"image\" src=\"images/play_button.png\" onmouseover=\"this.src='images/play_button_mouseover.png'\" onmouseout=\"this.src='images/play_button.png'\" alt=\"submit\" />";
      echo "</form>\n";
    }
  
  
  } elseif ($_SESSION["essai"]==$_SESSION['nbtry']){ // lorque que l'on arrive au nombre max d'essai si l'on a pas gagnez le message ci dessous est affiché et la solution est donnée
    echo "<br>Vous avez perdu !\n<br>La bonne réponse étais :\n<br>\n";
    for($i=0;$i<=3;$i++){
      if ($_SESSION['combinaison'][$i]==0){
        echo "<img src=\"images/0.png\" >\n";
      } elseif ($_SESSION['combinaison'][$i]==1) {
        echo "<img src=\"images/1.png\" >\n";
      } elseif ($_SESSION['combinaison'][$i]==2) {
        echo "<img src=\"images/2.png\" >\n";
      } elseif ($_SESSION['combinaison'][$i]==3) {
        echo "<img src=\"images/3.png\" >\n";
      }
    } 
    echo "<br>\n<img onclick=\"lose()\" src=\"images/replay_button.png\" onmouseover=\"this.src='images/replay_button_mouseover.png'\" onmouseout=\"this.src='images/replay_button.png'\"/>\n";
  
  
  } else {
    echo "<form action='mastermind.php' method='post'>\n";
    echo "<input id='pion0' type='hidden' name='pion0' value='vide' />\n";
    echo "<input id='pion1' type='hidden' name='pion1' value='vide' />\n";
    echo "<input id='pion2' type='hidden' name='pion2' value='vide' />\n";
    echo "<input id='pion3' type='hidden' name='pion3' value='vide' />\n";
    $r=$essai+1;
    $_SESSION["essai"]=$_SESSION["essai"]+1;
    echo "<input id='essai' type='hidden' name='essai' value=".$r." />\n";
    echo "<input type=\"image\" src=\"images/play_button.png\" onmouseover=\"this.src='images/play_button_mouseover.png'\" onmouseout=\"this.src='images/play_button.png'\" alt=\"submit\" />";
    echo "</form>\n";
  }
}

function generateur ($n,$essai) {

  for($i=0;$i<=$n;$i++) {                    //on crée n ligne qui représente le nombre de tentative
    echo "<tr>\n";
    if ($i==0) {
      echo "<td></td>";
    } else {
      echo "<td>".$i."</td>";
    } if(!empty($_SESSION["coup".$i])){

      for($j=0;$j<4;$j++){                     // on crée des cases pour l'affichage de la combonaison
        echo "<td>\n";
        echo ("<img id='$i.$j' src='images/".$_SESSION['coup'.$i][$j].".png' />\n");
        echo "</td>\n";


      }

      echo "<td class='bienplace'>\n";        // on crée une casse pour afficher le nombre de bille bien placées
      echo "<img src='images/BP_".$_SESSION['placement'.$i][0].".png'/>\n";
      echo "</td>\n";
      echo "<td class='malplace'>\n";        //on crée une casse pour afficher le nombre de bille de la bonne couleurs mal placées
      echo "<img src='images/BC_".$_SESSION['placement'.$i][1].".png'/>\n";
      echo "</td>\n" ;
      echo "</tr>\n";



    } else {

      for($j=0;$j<4;$j++){                     // on crée des cases pour l'affichage de la combonaison
      echo "<td>\n";
      echo "<img id='$i.$j' src='images/vide.png' />\n";
      echo "</td>\n";
      }
      echo "<td class='bienplace'>\n";        // on crée une casse pour afficher le nombre de bille bien placées
      echo "<img src='' />\n";
      echo "</td>\n";
      echo "<td class='malplace'>\n";        //on crée une casse pour afficher le nombre de bille mal placées
      echo "<img src='' />\n";
      echo "</td>\n" ;
      echo "</tr>\n";
    }
  }


}

function nouvelleCombinaison(){
  $code=array();

  for($i=0;$i<4;$i++) {
    $code[]=rand(0,3);
  }
  return $code;
}

function testPlace($coup,$comb){
  $malplace=0;
  $bien=0;
  $oc0=selecteur(compteurOccurence($coup,"0"),compteurOccurence($comb,"0"));
  $oc1=selecteur(compteurOccurence($coup,"1"),compteurOccurence($comb,"1"));
  $oc2=selecteur(compteurOccurence($coup,"2"),compteurOccurence($comb,"2"));
  $oc3=selecteur(compteurOccurence($coup,"3"),compteurOccurence($comb,"3"));
  $total=$oc0+$oc1+$oc2+$oc3;

  for ($i=0; $i <sizeof($coup) ; $i++) {
    if (! is_numeric($coup[$i])) {
          $coup[$i]=4;
    }
    if ( $coup[$i]==$comb[$i])  {
      $bien++;
    }
  }
  
  $total-=$bien;
  $valfin=array($bien,$total);
  return $valfin;
}

function selecteur($i,$o){

  if($i>$o) return $o;
  else return $i;
  
}
  
function recupOcc($oc0,$oc1,$oc2,$oc3,$occtest){
  $tabOcc=array($oc0,$oc1,$oc2,$oc3);
  if( $occtest== 0) return $tabOcc[0];
  else if( $occtest== 1) return $tabOcc[1];
  else if( $occtest== 2) return $tabOcc[2];
  else if( $occtest== 3) return $tabOcc[3];
  
}

function compteurOccurence($ori,$atest){
  $chaine=implode ( "," , $ori);
  return mb_substr_count($chaine, $atest);
}

?>


<!DOCTYPE html>
<html>

<head>
  <title>Mastermind</title>
  <link rel="icon" href="images/0.png">
  <meta charset="utf-8" />
  <link type="text/css" rel="stylesheet" href="mastermind.css" />
  <script type="text/javascript" src="mastermind.js"></script>
</head>

<body>

  <h1><img src="images/Mastermind_main.png" onmouseover="this.src='images/Mastermind_main_onmousover.png'" onmouseout="this.src='images/Mastermind_main.png'"  onclick="backtohome()" />
<script>
function backtohome() {
  if (confirm("Voulez vous quitter votre partie ?")) {
    window.location = "mastermind_home.php";
  }
}
</script>
</h1>

  <table>
    <!--
      La première ligne de la table est fixe : elle contient les
      images cliquables permettant au joueur de sélectionner ses pions
    -->
    <tr>
      <td>
      </td>
      <td>
        <img src="images/0.png" onclick="clic(0,this)" />
      </td>
      <td>
        <img src="images/1.png" onclick="clic(1,this)" />
      </td>
      <td>
        <img src="images/2.png" onclick="clic(2,this)" />
      </td>
      <td>
        <img src="images/3.png" onclick="clic(3,this)" />
      </td>
      <td class="bienplace">
      </td>
      <td class="malplace">
      </td>
    </tr>



<?php generateur($_SESSION['nbtry'],$_SESSION["essai"]); // génération de l'interface de jeu avec la fonction

?>

    <!--
      Cet élément est la ligne courante dans laquelle on fait appariatre les pions choisis par le joueur.
      Elle change a chaque coup (et passe à la ligne suivante)
    -->

  </table>

  <!--
    L'attribut 'value' des éléments INPUT est rempli par JavaScript.
    L'action du formulaire est le même script (mastermind.php).
  -->
<?php
formualaire($_SESSION['essai']);
?>
  <script> function lose() {
    window.location="mastermind_home.php";
  }
  </script>
  <p>
       Vincent Coppé <img class="logo" src="images/THEGANG.png" /> Jauffret Lucas <! nos noms, prénoms et notre logo en bas de page>
  </p>
</body>

</html>
