<!DOCTYPE html>
<html>

<head>
  <title>Mastermind</title>
  <meta charset="utf-8" />
  <link type="text/css" rel="stylesheet" href="mastermind.css" />
  <script type="text/javascript" src="mastermind.js"></script>
</head>

<body>

  <h1>Mastermind</h1>

<?php
  if ( isset($_GET["pion0"]) ) {
    echo "Le joueur a joué (dans l'ordre) : {$_GET['pion0']}, {$_GET['pion1']}, {$_GET['pion2']}, {$_GET['pion3']}";
  }
?>

  <table>
    <!--
      La première ligne de la table est fixe : elle contient les
      images cliquables permettant au joueur de sélectionner ses pions
    -->
    <tr>
      <td>
      </td>
      <td>
        <img src="images/0+vide.png" onclick="clic(0,this)" />
      </td>
      <td>
        <img src="images/1+vide.png" onclick="clic(1,this)" />
      </td>
      <td>
        <img src="images/2+vide.png" onclick="clic(2,this)" />
      </td>
      <td>
        <img src="images/3+vide.png" onclick="clic(3,this)" />
      </td>
      <td class="bienplace">
      </td>
      <td class="malplace">
      </td>            
    </tr>
<!-- Ce code HTML doit être généré par un script PHP -->
    <tr>
      <td>1</td>
      <td>
        <img src="images/1+vide.png" />
      </td>
      <td>
        <img src="images/3+vide.png" />
      </td>
      <td>
        <img src="images/0+vide.png" />
      </td>
      <td>
        <img src="images/2+vide.png" />
      </td>
      <td class="bienplace">
        <img src="images/bp_2.png" />
      </td>
      <td class="malplace">
      <img src="images/bc_1.png" />
      </td>      
    </tr>
    <tr>
      <td>2</td>
      <td>
        <img src="images/1+vide.png" />
      </td>
      <td>
        <img src="images/0+vide.png" />
      </td>
      <td>
        <img src="images/1+vide.png" />
      </td>
      <td>
        <img src="images/2+vide.png" />
      </td>
      <td class="bienplace">
      <img src="images/bp_2.png" />
      </td>
      <td class="malplace">
      <img src="images/bc_2.png" />
      </td>
    </tr>
    <!--
      Cet élément est la ligne courante dans laquelle on fait appariatre les pions choisis par le joueur.
      Elle change a chaque coup (et passe à la ligne suivante)
    -->
    <tr id="courant">
      <td>3</td>
      <td>
        <img src="images/1+vide.png" />
      </td>
      <td>
        <img src="images/1+vide.png" />
      </td>
      <td>
        <img src="images/0+vide.png" />
      </td>
      <td>
        <img src="images/2+vide.png" />
      </td>
      <td class="bienplace">
        <img src="images/bp_3.png" />
      </td>
      <td class="malplace">
      <img src="images/bc_1.png" />
      </td>
    </tr>
    <tr>
      <td>4</td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
    </tr>
    <tr>
      <td>5</td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
    </tr>
    <tr>
      <td>6</td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
    </tr>
    <tr>
      <td>7</td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
    </tr>
    <tr>
      <td>8</td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
    </tr>
    <tr>
      <td>9</td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
    </tr>
    <tr>
      <td>10</td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
      <td>
        <img src="images/vide.png" />
      </td>
    </tr>
  </table>

  <!--
    L'attribut 'value' des éléments INPUT est rempli par JavaScript.
    L'action du formulaire est le même script (mastermind.php).
  -->
  <form action="" method="get">
    <input id="pion0" type="hidden" name="pion0" value="0" />
    <input id="pion1" type="hidden" name="pion1" value="0" />
    <input id="pion2" type="hidden" name="pion2" value="0" />
    <input id="pion3" type="hidden" name="pion3" value="0" />
    <input type="submit" value="Jouer" />
  </form>
</body>

</html>