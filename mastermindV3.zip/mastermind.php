<?php
session_start();

  if(empty($_SESSION))$_SESSION=["nbtry" => $_POST['nbtry'],"combinaison" => nouvelleCombinaison()];




function generateur ($n){
for($i=0;$i<$n;$i++){                    //on crée n ligne qui représente le nombre de tentative
    echo "<tr>\n";
    echo "<td>".$i."</td>";
for($j=0;$j<4;$j++){                     // on crée des cases pour l'affichage de la combonaison
  echo "<td>\n";


  echo "<img id='$i.$j' src='images/vide.png' />\n";
  echo "</td>\n";
}

echo "<td class='bienplace'>\n";        // on crée une casse pour afficher le nombre de bille bien placées
echo "<img src='' />\n";
echo "</td>\n";
echo "<td class='malplace'>\n";        //on crée une casse pour afficher le nombre de bille mal placées
echo "<img src='' />\n";
echo "</td>\n" ;
echo "</tr>\n";
  }
}

function nouvelleCombinaison(){
  $code=[];
  for($i=0;$i<4;$i++){
    $code[$i]=rand(1,4);
  }
  return $code;
}

?>





<!DOCTYPE html>
<html>

<head>
  <title>Mastermind</title>
  <meta charset="utf-8" />
  <link type="text/css" rel="stylesheet" href="mastermind.css" />
  <script type="text/javascript" src="mastermind.js"></script>
</head>

<body>

  <h1>Mastermind</h1>

<?php
  if ( isset($_GET["pion0"]) ) {
    echo "Le joueur a joué (dans l'ordre) : {$_GET['pion0']}, {$_GET['pion1']}, {$_GET['pion2']}, {$_GET['pion3']}";
  }
?>

  <table>
    <!--
      La première ligne de la table est fixe : elle contient les
      images cliquables permettant au joueur de sélectionner ses pions
    -->
    <tr>
      <td>
      </td>
      <td>
        <img src="images/0.png" onclick="clic(0,this)" />
      </td>
      <td>
        <img src="images/1.png" onclick="clic(1,this)" />
      </td>
      <td>
        <img src="images/2.png" onclick="clic(2,this)" />
      </td>
      <td>
        <img src="images/3.png" onclick="clic(3,this)" />
      </td>
      <td class="bienplace">
      </td>
      <td class="malplace">
      </td>
    </tr>



<?php generateur($_SESSION['nbtry']); // génération de l'interface de jeu avec la fonction

?>

    <!--
      Cet élément est la ligne courante dans laquelle on fait appariatre les pions choisis par le joueur.
      Elle change a chaque coup (et passe à la ligne suivante)
    -->

  </table>

  <!--
    L'attribut 'value' des éléments INPUT est rempli par JavaScript.
    L'action du formulaire est le même script (mastermind.php).
  -->
  <form action="" method="get">
    <input id="pion0" type="hidden" name="pion0" value="" />
    <input id="pion1" type="hidden" name="pion1" value="" />
    <input id="pion2" type="hidden" name="pion2" value="" />
    <input id="pion3" type="hidden" name="pion3" value="" />
    <input type="submit" value="Jouer" />
  </form>
</body>

</html>
